#include <ArduinoDebugger.h>
#include <DebuggerF.h>
#include <Debugger.h>
/***
* @brief Constructor to determine if a debugger with or without float capabilities is initialized.
*
*  Handling floats requires a significant memory footprint. So to limit the size of the debugger library, the ability to work with floats was seperated into another class (DebuggerF). If usingFloat is set to true, then this method will return an instance using the DebuggerF class. If usingFloat is set to false, than an instance of the Debugger class will be returned and floats will not be viewed/updated with the debugger.
*
*  @param usingFloat - true - allow for float | false - don't allow for floats
*  @param is8Bit - true uses 8-Bit register, false - uses 32-Bit registers
**/
Debugger ArduinoDebugger::initialize(bool usingFloat, bool is8Bit)
{
	if(usingFloat)
	{
		DebuggerF debug(is8Bit);
		return debug;
	}
	else
	{
		Debugger debug(is8Bit);
		return debug;
	}
}