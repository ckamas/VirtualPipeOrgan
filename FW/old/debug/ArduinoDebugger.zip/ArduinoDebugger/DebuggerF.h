#ifndef _DEBUGGER_F_H_
#define _DEBUGGER_F_H_
#include <Arduino.h>
#include <Debugger.h>
class DebuggerF : public Debugger{
public:
  void displayVariables();
	void updateVariables();
	DebuggerF(bool is8Bit) : Debugger(is8Bit){};

private:
  float getFloat();	
	void displayArray(Variable var);
	void updateArray(Variable var);
};
#endif