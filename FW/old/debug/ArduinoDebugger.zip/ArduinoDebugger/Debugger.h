#ifndef _DEBUGGER_H_
#define _DEBUGGER_H_
#include <Arduino.h>

/**
* \struct Type Debugger.h "ArduinoDebugger/Debugger.h"
* Type defines the data types supported by the Arduino Debugger. 
* This will be used for casting the memory address in the Variable struct.
*/
enum Type
{
		BYTE,
		BYTE_ARRAY,
		INT,
		INT_ARRAY,
		LONG,
		LONG_ARRAY,
		FLOAT,
		FLOAT_ARRAY,
		CHAR,
		CHAR_ARRAY,
		BOOL,
		BOOL_ARRAY
}; 

/**
* The Variable struct holds a variables memory address, data type, and a character representation of its name.
*/
struct Variable
{
	void* ptr; ///< A variable's memory address
	Type type; ///< Used for casting the variables data into the correct data primitive.
	char name[16];///< The actual name of the variable so it can be displayed/referenced in a human readable format.
};
  
//Counter IDs
#define REPEAT_0 0
#define REPEAT_1 1
#define REPEAT_2 2
#define REPEAT_3 3
#define REPEAT_4 4

/*! \def VARIABLES
    \brief Display only variables (0)
		A constant to have repeat() or print() display only variable values 

    \def PINS
    \brief Display only pin values (1)
		A constant to have repeat() or print() display only hardware pin values 
		
		\def ALL_DATA
    \brief Display both variables and pins (2)
		A constant to have repeat() or print() display both variable and hardware pin values 
*/
//Data Display Options
#define VARIABLES 0
#define PINS 1
#define ALL_DATA 2

/*! \def BITS_8
    \brief 8 Bit microcontroller (true)
		A constant to set the debugger to work with 8 Bit microcontrollers

    \def BITS_32
    \brief 32 Bit microcontroller (false)
		A constant to set the debugger to work with 32 Bit microcontrollers
*/

#define BITS_8 true
#define BITS_32 false

class Debugger{
	public:
		Debugger(bool is8Bit);
		
		//Turn off debugging
		void turnOff();
		void turnOn();
		
		//Breakpoints
		void breakpoint();
		void breakpoint(char name[]);
		
		//Repeat
		void repeat();//Defaults to Counter 0 at 3 iterations
		void repeat(byte value);//Set default counter
		void repeat(byte id, byte value);//Set specific counter's value
		void repeat(byte id, byte value, byte data);//Chose counter & information to display
		
		//Set Counters for Update
		void setCounter(byte id, byte value);
		
		//Print data
		void print();
		void print(char name[]);
		void print(char name[], byte data);
		
		//Handle Variables
		void add(void* var_ptr, Type type, char var_name[]);
		void remove(char var_name[]);
		virtual void displayVariables(); //Can't handle floats in this implementation
		virtual void updateVariables(); //Can't handle floats in this implementation
		
		//Handle Hardware Pins
		void displayPins();
		void displaySubsetPins();
		void setSubsetPins(byte digital_pins[], byte size_d, byte analog_pins[], byte size_a);//Create a subset of pins
		void resetSubsetPins();//Reset subset list, NO CHOSEN PINS
		void updatePins(bool displayAll);
		
		//Get data type values from Serial Input
		long getNumber(bool &valid, Type type);
		char getChar();
		bool getBool(bool &valid);
		void pause();
		
		//Handle screen displays
		void clearScreen();
		void clearBuffer();
		void drawStars();
		
	protected:

		bool _is8Bit;///< This boolean helps determine if the microcontroller uses 8-Bit or 32-Bit registers
								///< True - registers will be cast for 8-bits uint8_t
								///< False - registers will be cast for 32-bits uint32_t
	
		bool debuggingIsOn = true;
	
		//Variable watchlist
		Variable var_watch[10]; ///< Holds information on the variable's being tracked
		byte top_var_watch = 0; ///< References max number of variables currently being watched.
		
		//Chosen subset of digital/analog pins
		bool usePinList = false; ///< Set to true by setPins() and allows the debugger to show a subset of pins
		byte digital_size = 0;   ///< Number of digital pins in the subset
		byte analog_size = 0;    ///< Number of analog pins in the subset
		byte digital_pins[10];   ///< Array listing the subset of digital pins
		byte analog_pins[10];    ///< Array listing the subset of analog pins
		
		//counters for update() method
		byte counters[5] = {0,0,0,0,0}; ///< Allows for 5 individual update counters
		byte counters_max[5] = {0,0,0,0,0}; ///< Tracks the maximum value for each counter
		
		//Array helper methods
		void printName(char name[]); 
		byte getSize(char name[]);
		virtual void displayArray(Variable var);
		virtual void updateArray(Variable var);
		
		//Menu/Serial helper methods
		byte getSelection();
		int timedPeek();
	
};

#endif