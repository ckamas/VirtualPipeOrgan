var annotated_dup =
[
    [ "ArduinoDebugger", "class_arduino_debugger.html", null ],
    [ "Debugger", "class_debugger.html", "class_debugger" ],
    [ "DebuggerF", "class_debugger_f.html", "class_debugger_f" ],
    [ "Type", "struct_type.html", null ],
    [ "Variable", "struct_variable.html", "struct_variable" ]
];