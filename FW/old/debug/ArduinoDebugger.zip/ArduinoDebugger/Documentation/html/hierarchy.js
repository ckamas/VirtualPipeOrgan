var hierarchy =
[
    [ "ArduinoDebugger", "class_arduino_debugger.html", null ],
    [ "Debugger", "class_debugger.html", [
      [ "DebuggerF", "class_debugger_f.html", null ]
    ] ],
    [ "Type", "struct_type.html", null ],
    [ "Variable", "struct_variable.html", null ]
];