var struct_variable =
[
    [ "name", "struct_variable.html#a7dd636b93bc19a471bf1fa145ff84478", null ],
    [ "ptr", "struct_variable.html#a483995f377f3e83143301b4d6f18b021", null ],
    [ "type", "struct_variable.html#aaed0b2b954ecc69f45c93e09e7969463", null ]
];