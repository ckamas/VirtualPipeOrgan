var searchData=
[
  ['variables_162',['VARIABLES',['../_debugger_8h.html#a67a7c8399fe9f3185efe2dcf0ceec371',1,'Debugger.h']]]
];
