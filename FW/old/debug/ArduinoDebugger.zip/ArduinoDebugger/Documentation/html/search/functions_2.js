var searchData=
[
  ['clearbuffer_94',['clearBuffer',['../class_debugger.html#a756910a6d424cba8ab2bd2f324368f9e',1,'Debugger']]],
  ['clearscreen_95',['clearScreen',['../class_debugger.html#ad127d23b5966d0afd8ddd32de636346e',1,'Debugger']]]
];
