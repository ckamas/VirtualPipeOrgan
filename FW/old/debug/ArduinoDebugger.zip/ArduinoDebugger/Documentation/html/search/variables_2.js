var searchData=
[
  ['counters_127',['counters',['../class_debugger.html#abe896aa645c96100e406ec228bcba54e',1,'Debugger']]],
  ['counters_5fmax_128',['counters_max',['../class_debugger.html#a932a7a4f1d28868e821bf775c6ffd5d5',1,'Debugger']]]
];
