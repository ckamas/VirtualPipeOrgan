var searchData=
[
  ['top_5fvar_5fwatch_134',['top_var_watch',['../class_debugger.html#aa82ff8205345d92e3bcef19c2b70dab8',1,'Debugger']]],
  ['type_135',['type',['../struct_variable.html#aaed0b2b954ecc69f45c93e09e7969463',1,'Variable']]]
];
