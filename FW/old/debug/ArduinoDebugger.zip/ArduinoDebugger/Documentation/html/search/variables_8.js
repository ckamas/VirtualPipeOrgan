var searchData=
[
  ['var_5fwatch_137',['var_watch',['../class_debugger.html#a310c285c7a1733a1a344b4e1d9a70076',1,'Debugger']]]
];
