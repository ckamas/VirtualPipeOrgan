var searchData=
[
  ['add_92',['add',['../class_debugger.html#a929bf8fd84f5e6cbdf36aeba748f8ff1',1,'Debugger']]]
];
