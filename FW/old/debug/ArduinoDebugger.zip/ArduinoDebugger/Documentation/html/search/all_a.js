var searchData=
[
  ['name_51',['name',['../struct_variable.html#a7dd636b93bc19a471bf1fa145ff84478',1,'Variable']]],
  ['no_5ffloats_52',['NO_FLOATS',['../_arduino_debugger_8h.html#afe05364eabc293166f0123e48f21d418',1,'ArduinoDebugger.h']]]
];
