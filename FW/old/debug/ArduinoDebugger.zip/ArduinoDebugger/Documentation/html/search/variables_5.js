var searchData=
[
  ['ptr_133',['ptr',['../struct_variable.html#a483995f377f3e83143301b4d6f18b021',1,'Variable']]]
];
