var searchData=
[
  ['analog_5fpins_125',['analog_pins',['../class_debugger.html#afc6599fcafbcdde9130c9be05b4923e5',1,'Debugger']]],
  ['analog_5fsize_126',['analog_size',['../class_debugger.html#a6293b27beab5a5f9ce435dd9faaab2c7',1,'Debugger']]]
];
