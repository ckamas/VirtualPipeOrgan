var searchData=
[
  ['variable_84',['Variable',['../struct_variable.html',1,'']]]
];
