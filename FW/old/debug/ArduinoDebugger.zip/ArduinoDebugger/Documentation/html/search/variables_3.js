var searchData=
[
  ['debuggingison_129',['debuggingIsOn',['../class_debugger.html#a9a1d7ab8b77d13dd82b1ead871db31f8',1,'Debugger']]],
  ['digital_5fpins_130',['digital_pins',['../class_debugger.html#a6526ed02d6993e64491a924860345c7d',1,'Debugger']]],
  ['digital_5fsize_131',['digital_size',['../class_debugger.html#ac3c561b3d29ef0dc82a4b710c26a6d87',1,'Debugger']]]
];
