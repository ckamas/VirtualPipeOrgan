var searchData=
[
  ['name_132',['name',['../struct_variable.html#a7dd636b93bc19a471bf1fa145ff84478',1,'Variable']]]
];
