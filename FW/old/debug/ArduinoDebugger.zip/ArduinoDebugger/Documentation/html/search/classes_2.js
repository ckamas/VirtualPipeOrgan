var searchData=
[
  ['type_83',['Type',['../struct_type.html',1,'']]]
];
