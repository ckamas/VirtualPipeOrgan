var _arduino_debugger_8h =
[
    [ "ArduinoDebugger", "class_arduino_debugger.html", null ],
    [ "FLOATS", "_arduino_debugger_8h.html#a22f9177e57e691e63cd6771c7f240609", null ],
    [ "NO_FLOATS", "_arduino_debugger_8h.html#afe05364eabc293166f0123e48f21d418", null ]
];