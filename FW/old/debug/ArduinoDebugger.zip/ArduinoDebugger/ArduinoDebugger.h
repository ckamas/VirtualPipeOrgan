#ifndef _ARDUINO_DEBUGGER_H_
#define _ARDUINO_DEBUGGER_H_
#include <Arduino.h>
#include <Debugger.h>
#include <DebuggerF.h>

#define FLOATS true
#define NO_FLOATS false

class ArduinoDebugger{
public:

	static Debugger initialize(bool usingFloat, bool is8Bit);

};
#endif