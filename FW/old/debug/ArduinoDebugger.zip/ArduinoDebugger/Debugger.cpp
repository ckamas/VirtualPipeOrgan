
#include <Debugger.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/**********************************************************
* @brief Debugger Constructor
*
*  This constructor will set the is8Bit boolean to determine
*  if the microcontroller uses 8Bit or 32Bit registers
* 
* @param is8Bit True - 8Bit | False - 32Bit
***********************************************************/
Debugger::Debugger(bool is8Bit)
{
	_is8Bit = is8Bit;
	
}

/**********************************************************
* @brief Turn debugging info off
*
*  This method will prevent update() and breakpoint() methods 
*  displaying debugging information. It will only affect these two methods.
*  All other methods will potentially display error messages.
***********************************************************/
void Debugger::turnOff()
{
	debuggingIsOn = false;
}

/**********************************************************
* @brief Turn debugging info on
*
*  This method will allow update() and breakpoint() methods 
*  to display debugging information.
***********************************************************/
void Debugger::turnOn()
{
	debuggingIsOn = true;
}

/**********************************************************
* @brief Set a breakpoint with no name
*
*  The breakpoint method will provide a menu to the user so that they can view & update the systems:
*			- Hardware Pins
*			- Watched Variables
***********************************************************/
void Debugger::breakpoint()
{
	breakpoint("");
}

/**********************************************************
* @brief Set a breakpoint with a label to help indentify
*				 which breakpoint in the program is being viewed.
*
*  The breakpoint method will provide a menu to the user so that they can view & update the systems:
*			- Hardware Pins
*			- Watched Variables
*	 
*	@param name A string for labeling the breakpoint.  
***********************************************************/
void Debugger::breakpoint(char name[])
{
	if(debuggingIsOn)
	{
		clearScreen();//Clear Screen
		byte selection;
		do{
			//Debugger Menu
			Serial.print(F("\tBreakpoint - "));
			Serial.println(name);
			
			//Chose the menu display based on if a subset of pins has been set
			if(usePinList)
			{
				Serial.println(F("1. Variables \n2. Hardware Pins (All) \n3. Harware Pins(Subset)"));
			}
			else
			{
				Serial.println(F("1. Variables \n2. Hardware Pins"));
			}
			Serial.println(F("What component would you like to view and/or update?"));
			selection = getSelection();
			
			switch(selection)
			{
				case 1://1. Display Variable Values  
					clearScreen();
					updateVariables();
					clearScreen();
					break;
					
				case 2://1. Display All Pin States
					clearScreen();
					updatePins(true);
					clearScreen();
					break;
					
				case 3://2. Display Subset of Pin States
					clearScreen();
					updatePins(false);
					clearScreen();
					break;
					
				case 4://Exit debugging 
				case 255://Accepts Q 
					selection = 4;
					Serial.println(F("\nContinuing Program"));
					break;
					
				default:
					clearScreen();
					Serial.println(F("Invalid Selection"));
			}
		}while(selection != 4);
	}
}

/**********************************************************
* @brief Add a variable to the debugger's watch list.
*
*  A watched variable can be viewed or updated via the breakpoint method.  The update method will only display the value of the variables added.
*   
*	@param ptr The memory location of a variable being watched
*	@param type This is an enum representing the variable's data type
*	@param name	The name of variable being watched
***********************************************************/
void Debugger::add(void *ptr, Type type, char name[])
{
	if(strlen(name) <= 15)
	{//Verify name will fit inside a struct's name (char[16])

		bool exists = false;//Checks if variable already exists
		for(byte i = 0; i < top_var_watch; i++)
		{
			Variable check = var_watch[i];
			if(strcmp(check.name, name) == 0)
			{//Variable name found
				exists = true;
			}
		}
		if(!exists)
		{//Verify the variable has not already been added to the watch list
			Variable temp = {ptr, type};
			memcpy(temp.name, name, strlen(name) + 1);
			if(top_var_watch < sizeof(var_watch)/sizeof(var_watch[0]))
			{//Check that there is room for an additional variable
				var_watch[top_var_watch] = temp;
				top_var_watch += 1;
			}
			else
			{//Error watch list is full
				clearScreen();
				drawStars();
				Serial.print(F("Can't add "));
				Serial.println(name);
				Serial.println(F("Too many variables in watch"));
				drawStars();
			}
		}
	}
	else
	{//Error name is too long
		Serial.print(name);
		Serial.println(F("-Name must be <=15 characters"));
	}
}

/**********************************************************
* @brief Remove a variable to the debugger's watch list.
*
*  This method will remove a variable from the watch list based on its name.
*  @warning This method requires an exact match and is case sensitive. 
*
*	@param var_name	The name of variable being removed
***********************************************************/
void Debugger::remove(char var_name[])
{
	bool found = false;
	for(byte i = 0; i < top_var_watch; i++)
	{
		Variable temp = var_watch[i];
		if(!found)
		{
			if(strcmp(temp.name, var_name) == 0)
			{//Variable name found
				found = true;
			}
		}
		else
		{//Once the variable is found, replace it with the remaining entries
			var_watch[i - 1] = temp;//Replace the previous entry
		}
	}
	if(!found)
	{//Variable wasn't found
		Serial.print(F("Unable to remove "));
		Serial.println(var_name);
		Serial.println(F("It was not listed in the variable watch"));
	}
	else
	{
		top_var_watch--;
	}
}



/**********************************************************
* @brief Display current Digital/Analog value of all pins.
*
*  This method will display the current state of all Digital &
*	 Analog Pins. Analog Pin states range from 0-1023. Digital Pins have 
*  3 potential states:
* 	- HIGH (Power In) 
*			- Receiving power in
* 	- HIGH
*			- Providing power out
*		- LOW
*			- No Power
*
*  The method also allows for the state of a Digital Pin 
*	 to be updated (HIGH/LOW).  
*
* @note Currently, this method does not supported viewing/updating PWM values.
*  
*	 
***********************************************************/
void Debugger::displayPins()
{
	drawStars();
	Serial.println(F("\t\tDigital Pin State\n\tPin Number : State(LOW/HIGH/HIGH(Power In)"));
	drawStars();
	for(int i = 0; i < NUM_DIGITAL_PINS; i++)
	{
		Serial.print(F("\t"));
		if(i < 10)
		{
			Serial.print(F(" "));//Add extra space for single digits
		}
		Serial.print(i);
		Serial.print(F(" : "));
		bool power_out = false;
		volatile void* out;
		if(_is8Bit)
		{//Use 8 bit values for AVR chips
			uint8_t bit_val = digitalPinToBitMask(i);
			out = portOutputRegister(digitalPinToPort(i));
			bit_val &= *static_cast<volatile uint8_t*>(out);
			if(bit_val > 0)
			{
				power_out = true;
			}
		}
		else
		{//Non AVR chips (SAMD or NRF [:Bit]) use 32 bit
			uint32_t bit_val = digitalPinToBitMask(i);
			out = portOutputRegister(digitalPinToPort(i));
			bit_val &= *static_cast<volatile uint32_t*>(out);
			if(bit_val > 0)
			{
				power_out = true;
			}
		}
		
		if(power_out)
		{//Pin set to HIGH -> Providing Power
			Serial.println(F("HIGH"));
		}
		else if(digitalRead(i) == HIGH)
		{
			Serial.println(F("HIGH(Power In)"));
		}
		else
		{
			Serial.println(F("LOW"));
		}		
	}
	
	drawStars();
	Serial.println(F("\t\tAnalog Pin State\n\tPin Number : Analog Value"));
	drawStars();
	for(int i = A0; i < NUM_ANALOG_INPUTS + A0; i++)
	{
		Serial.print(F("\t"));
		Serial.print(F("A"));
		Serial.print(i-A0);
		Serial.print(F(" : "));
		Serial.println(analogRead(i));
	}
}

/**********************************************************
* @brief Set a subset of Digital/Analog pins to display to the user
*
*  This method will set the digital_pins & analog_pins member arrays.
*  These are used for displaying a subset of available digital and analog pins
*  which will reduce the amount of information displayed to and shifted through 
*  by the user.
*  
* @warning This method cannot verify that size_d or size_a match the number of pins in d_pins or a_pins. 
*						 If a pin is missing from the subset, please ensure that size_d and size_a are correct.
* @param d_pins An array of the digital pin numbers
* @param size_d The size of d_pins, i.e. the number of digital pins being included
* @param a_pins An array of the analog pin numbers
* @param size_a The size of a_pins, i.e. the number of analog pins being included
*	 
***********************************************************/
void Debugger::setSubsetPins(byte d_pins[], byte size_d, byte a_pins[], byte size_a)
{
	//Verify digital_pins can hold all of the provided pins
	if(size_d > sizeof(digital_pins)/sizeof(digital_pins[0]))
	{
		Serial.print(F("size_d must be less than "));
		Serial.println(sizeof(digital_pins)/sizeof(digital_pins[0]));
	}
	//Verify analog_pins can hold all of the provided pins
	else if(size_a > sizeof(analog_pins)/sizeof(analog_pins[0]))
	{
		Serial.print(F("size_a must be less than "));
		Serial.println(sizeof(analog_pins)/sizeof(analog_pins[0]));
	}
	else
	{//store the pin numbers
		usePinList = true;
		for(byte i = 0; i < size_d; i++)
		{
			digital_pins[i] = d_pins[i];
		}
		digital_size = size_d;
		
		for(byte i = 0; i < size_a; i++)
		{
			analog_pins[i] = a_pins[i];
		}
		analog_size = size_a;
	}
}

/**********************************************************
* @brief No longer use a subset list of pins
*
*  This method will turn of the subset feature. 
*  
* @note  This method does not actually remove the subset of pins. Instead it flips a boolean (usePinList) to determine if a subset of pins should be displayed. This means the arrays digital_pins and analog_pins are not modified.
***********************************************************/
void Debugger::resetSubsetPins()
{
	usePinList = false;
}

/**********************************************************
* @brief Display current Digital/Analog value for the subset of pins.
*
*  This method will display the current state of the Digital &
*	 Analog Pins referenced in the current subset. Analog Pin states range from 0-1023. 
*  Digital Pins have 3 potential states:
* 	- HIGH (Power In) 
*			- Receiving power in
* 	- HIGH
*			- Providing power out
*		- LOW
*			- No Power
*
*  The method also allows for the state of a Digital Pin 
*	 to be updated (HIGH/LOW).  
*
* @note If digital_size is 0, then the digital pins will not be displayed. If analog_size is 0, then the analog pins will not be displayed.
*  
***********************************************************/
void Debugger::displaySubsetPins()
{
	//Verify there are digital pins to display
	if(digital_size > 0)
	{
		Serial.println(F("\t\tDigital Pin State\n\tPin Number : State(LOW/HIGH/HIGH(Power In)"));
		drawStars();
		for(int i = 0; i < digital_size; i++)
		{
			Serial.print(F("\t"));
			if(digital_pins[i] < 10)
			{
				Serial.print(F(" "));//Add extra space for single digits
			}
			Serial.print(digital_pins[i]);
			Serial.print(F(" : "));
			bool power_out = false;
			volatile void* out;
			if(_is8Bit)
			{//Use 8 bit values for AVR chips
				uint8_t bit_val = digitalPinToBitMask(digital_pins[i]);
				out = portOutputRegister(digitalPinToPort(digital_pins[i]));
				bit_val &= *static_cast<volatile uint8_t*>(out);
				if(bit_val > 0)
				{
					power_out = true;
				}
			}
			else
			{//Non AVR chips (SAMD or NRF [:Bit]) use 32 bit
				uint32_t bit_val = digitalPinToBitMask(digital_pins[i]);
				out = portOutputRegister(digitalPinToPort(digital_pins[i]));
				bit_val &= *static_cast<volatile uint32_t*>(out);
				if(bit_val > 0)
				{
					power_out = true;
				}
			}
			
			if(power_out)
			{//Pin set to HIGH
				Serial.println(F("HIGH"));
			}
			else if(digitalRead(digital_pins[i]) == HIGH)
			{
				Serial.println(F("HIGH(Power In)"));
			}
			else
			{
				Serial.println(F("LOW"));
			}
		}
	}
	
	//Verify there are analog pins to display
	if(analog_size > 0)
	{
		drawStars();
		Serial.println(F("\t\tAnalog Pin State\n\tPin Number : Analog Value"));
		drawStars();
		for(int i = 0; i < analog_size; i++)
		{
			int a_val = 0;
			for(int analog = A0; analog < NUM_ANALOG_INPUTS + A0; analog++)
			{
				if(analog_pins[i] == analog)
				{
					Serial.print(F("\t"));
					Serial.print(F("A"));
					Serial.print(a_val);
					break;
				}
				a_val++;
			}
			
			Serial.print(F(" : "));
			Serial.println(analogRead(analog_pins[i]));
		}
	}
}

/**********************************************************
* @brief Prompt the user for the value to update the digital pin to.
*
*  This method will prompt the user for the digital pin to update and its new value.
*
*  @note If an invalid value is entered, no change will be made to the pin. Also, only the first character is actually used.
*  
*	 @param displayAll True - Display all pins | False - only display the subset of pins
***********************************************************/
void Debugger::updatePins(bool displayAll)
{
	byte selection = 'Q';
	//Determine if all pins or only a subset of pins will be displayed
	if(displayAll)
	{
		displayPins();
	}
	else
	{
		displaySubsetPins();
	}
	Serial.println(F("Enter the Pin Number for the Digital Pin to be updated."));
	byte pin = getSelection();
	while(pin != 255)//Ensure valid pin was selcted
	{
		//Verify the pin is a valid value for the microcontroller.
		//I.e. the Arduno Uno doesn't have a digital pin 54 but the Arduino Mega does
		if(pin < NUM_DIGITAL_PINS && pin != 254)
		{
			Serial.print(F("Set "));
			Serial.print(pin);
			Serial.print(F(" to (H)IGH or (L)OW: "));
			while(Serial.available() == 0){}
			byte state = Serial.peek();
			while(Serial.available() != 0)
			{
				Serial.print((char)Serial.read());//Echo value back to Serial Monitor
			}
			
			clearScreen();
			if(state == 'H' || state == 'h')
			{
				digitalWrite(pin, HIGH);
			}
			else if(state == 'L' || state == 'l')
			{
				digitalWrite(pin, LOW);
			}
			else
			{
				Serial.println(F("Invalid Value"));
			}
		}
		else
		{
			Serial.println(F("Invalid Selection"));
		}
		clearBuffer();
		if(displayAll)
		{
			displayPins();
		}
		else
		{
			displaySubsetPins();
		}
		pin = getSelection();	
	}
	drawStars();
}

/**********************************************************
* @brief Display all variables being watched with their current values.
*
*  This method will display each of the variables (w/ their values) 
*  that have been added to the watch list (via add() method).  
*  @warning This implementation does not support floats. Floats are handled by DebuggerF's implementation of this method 
*	 
* @note This method uses the displayArray() method to display any array variables.
***********************************************************/
void Debugger::displayVariables()
{
	Serial.println(F("\t\tVariable Watch"));
	Serial.println(F("\t[index] variable_name (type) : value"));
	drawStars();
	for(int i =0; i < top_var_watch; i++)
	{
		 Variable temp = var_watch[i];
		 Serial.print(F("\t["));
		 Serial.print(i);
		 Serial.print(F("] "));
		 switch(temp.type)
		 {		
				case BYTE:
				  Serial.print(temp.name);
					Serial.print(F(" (byte): "));
					Serial.println(*((byte*)temp.ptr));
					break;
					
				case Type::INT:
					Serial.print(temp.name);
					Serial.print(F(" (int): "));
					Serial.println(*((int*)temp.ptr));
					break;
			
				case Type::LONG:
					Serial.print(temp.name);
					Serial.print(F(" (long): "));
					Serial.println(*((long*)temp.ptr));
					break;
					
				case Type::FLOAT:
					Serial.print(temp.name);
					Serial.println(F(" (float): Set usingFloats to true in initalize()"));
					break;
					
				case Type::CHAR:
					Serial.print(temp.name);
					Serial.print(F(" (char): "));
					Serial.println(*((char*)temp.ptr));
					break;
						
				case Type::BOOL:
					Serial.print(temp.name);
					if(*(bool*)(temp.ptr))
					{
					Serial.print(F(" (bool): true"));
					}
					else
					{
						Serial.print(F(" (bool): false"));
					}
					break;
					
				case Type::BYTE_ARRAY:
				case Type::INT_ARRAY:
				case Type::LONG_ARRAY:
				case Type::FLOAT_ARRAY:
				case Type::CHAR_ARRAY:
				case Type::BOOL_ARRAY:
					displayArray(temp);
					break;
		 }
	}
	drawStars();
}

/**********************************************************
* @brief Prompt the user for the value to update the chosen variable to.
*
*  This method will prompt the user for a new value to use for a chosen
*  variable and validate the new value. 
*
*  @note The variable is only updated if a valid value is entered.
*  Invalid values will cause error messages to be displayed.
*
*  @warning  Data validation is limited. This method will attempt to ensure impossible data isn't used (ex. a byte set to -1) but does not guarantee to stop all invalid data entries}
*  
***********************************************************/
void Debugger::updateVariables()
{
	displayVariables();
	Serial.println(F("Enter the index of the variable to be updated.")); 
	byte index = getSelection();
	while(index != 255)
	{
		if(index < top_var_watch && index != 254)
		{//Verify valid index was chosen
			Variable temp = var_watch[index];
			bool valid = true;
			long retrieved_val = 0;
			if(temp.type == Type::BYTE_ARRAY || 
				 temp.type == Type::INT_ARRAY ||
				 temp.type == Type::FLOAT_ARRAY ||
				 temp.type == Type::LONG_ARRAY ||
				 temp.type == Type::CHAR_ARRAY ||
				 temp.type == Type::BOOL_ARRAY)
			{
				updateArray(temp);
			}
			else
			{
				Serial.print(F("New value for "));
				Serial.print(temp.name);
				switch(temp.type)
				{					
					case Type::BYTE:
						Serial.print("(byte): ");
						retrieved_val = getNumber(valid, Type::BYTE);
						if(valid)
						{
							clearScreen();
							*(byte*)(temp.ptr) = (byte) retrieved_val;
						}
						break;
					
					case Type::INT:
						Serial.print("(int): ");
						retrieved_val = getNumber(valid, Type::INT);
						if(valid)
						{
							clearScreen();
							*(int*)(temp.ptr) = (int) retrieved_val;
						}
						break;
						
					case Type::LONG:
						Serial.print("(long): ");
						retrieved_val = getNumber(valid, Type::LONG);
						if(valid)
						{
							clearScreen();
							*(long*)(temp.ptr) = (long) retrieved_val;
						}
						break;
					
					case Type::FLOAT:
						Serial.println(F(" (float): Set usingFloats to true in Debugger::initalize()"));
						break;
						
					case Type::CHAR:
						*(char*)(temp.ptr) = getChar();
						break;
						
					case Type::BOOL: 
						bool temp_bool = getBool(valid);
						if(valid)
						{
							*(bool*)(temp.ptr) = temp_bool;
						}
						break;
				}
			}
		}
		else
		{
			Serial.println(F("Invalid Selection"));
		}
		displayVariables();
		index = getSelection();
	}
}

/**********************************************************
* @brief Display an array variable's name
*
*  This method will parse an array variable's name from the Variable.name attribute. The expected format for 
*  array names is as follows:
*
*    varName_SIZE
*
*  An example of an array name would be:
*
*  int data_entries = {3, 2, 1};
*
*  Formatted name: data_entries_3
*
*  @warning If no underscore is found, then an error message will be displayed. Also, this method does not verify that there is a number after the underscore. It only trims the variable name to remove the last underscore and the characters after it. 
*  
***********************************************************/
void Debugger::printName(char name[])
{
	//Expected format for array variable name:
	//     varName_SIZE
	// Ex: pins_20
	char trim_name[16];
	char* ptr = strrchr(name, '_');
	if(ptr != NULL)
	{
		int size = ptr - name;
		strncpy(trim_name, name, size);
		trim_name[size] = 0;
		Serial.print(trim_name);
	}
	else
	{
		Serial.println(F("Warning, no '_' was found in the array variable's name. Name Entered: "));
		Serial.print(name);
	}
}

/**********************************************************
* @brief Parse the size of an array from it's name.
*
*  This method will parse an array variable's size from the Variable.name attribute. The expected format for 
*  array names is as follows:
*
*    varName_SIZE
*
*  An example of an array name would be:
*
*  int data_entries = {3, 2, 1};
*
*  Formatted name: data_entries_3
*
*  @warning If no underscore is found, then an error message will be displayed. 
*  
***********************************************************/
byte Debugger::getSize(char name[])
{
	//Expected format for array variable name:
	//     varName_SIZE
	// Ex: pins_20
	char* end = strchr(name, '_');//The last underscore is the end of the variable name
	byte size = 0;
	if(end != NULL)
	{
		size=atoi(end + 1);//Convert to a whole number
	}

	return size;
}

/**********************************************************
* @brief Display an array variable's data.
*
*  This method will display all of the values inside of an array variable.
*  @warning This implementation does not support floats. Floats are handled by DebuggerF's implementation of this method 
*
*  @warning This method does not provide data protection. It cannot determine if it is viewing data outside the array! I.e. no out-of-bounds errors will be given like in Java. Ensure that the size listed in the arrays name (varName_SIZE) is correct 
*	 
***********************************************************/
void Debugger::displayArray(Variable var)
{
	printName(var.name);
	switch(var.type)
		{
			case Type::BYTE_ARRAY:
				Serial.println(F(" byte[]:"));
				break;
				
			case Type::INT_ARRAY:
				Serial.println(F(" int[]:"));
				break;
				
			case Type::LONG_ARRAY:
				Serial.println(F(" long[]:"));
				break;
				
			case Type::CHAR_ARRAY:
				Serial.println(F(" char[]:"));
				break;
				
			case Type::BOOL_ARRAY:
			  Serial.println(F(" bool[]:"));
				break;
		}
		
	//Display each value of the array.
	byte size = getSize(var.name);
	for(byte i = 0; i < size; i++ )
	{
		Serial.print(F("\t\t"));
		printName(var.name);
		Serial.print(F("["));
		Serial.print(i);
		Serial.print(F("]: "));
		switch(var.type)
		{
			case Type::BYTE_ARRAY:
				Serial.println(((byte*)var.ptr)[i]);
				break;
				
			case Type::INT_ARRAY:
				Serial.println(((int*)var.ptr)[i]);
				break;
				
			case Type::LONG_ARRAY:
				Serial.println(((long*)var.ptr)[i]);
				break;
				
			case Type::CHAR_ARRAY:
				Serial.println(((char*)var.ptr)[i]);
				break;
				
			case Type::BOOL_ARRAY:
			  if(((bool*)var.ptr)[i])
				{
					Serial.println(F("true"));
				}
				else
				{
					Serial.println(F("false"));
				}
				break;
		}
	}
}

/**********************************************************
* @brief Prompt the user for the value to update the chosen index's value to.
*
*  This method will prompt the user for a new value to use for a chosen
*  array at a chosen array index.
*
*  @note The variable is only updated if a valid value is entered.
*  Invalid values will cause error messages to be displayed.
*
*  @warning Data validation is limited. This method will attempt to ensure impossible data isn't used (ex. a byte set to -1) but does not guarantee to stop all invalid data entries
*  
***********************************************************/
void Debugger::updateArray(Variable var)
{
	clearScreen();
	displayArray(var);
	Serial.println(F("Enter array index to be updated."));
	byte index = getSelection();
	while(index != 255 )
	{
		byte size = getSize(var.name);
		//Ensure the index is valid for the chosen array
		if(index < size && index != 254)
		{
			bool valid = true;
			long retrieved_val = 0;
			Serial.print(F("New value for ["));
			Serial.print(index);
			Serial.println(F("]: "));
			switch(var.type)
			{
				case Type::BYTE_ARRAY:
					retrieved_val = getNumber(valid, Type::BYTE);
					if(valid)
					{
						((byte*)var.ptr)[index] = (byte)retrieved_val;
					}
					break;
					
				case Type::INT_ARRAY:
					retrieved_val = getNumber(valid, Type::INT);
					if(valid)
					{
						((int*)var.ptr)[index] = (int)retrieved_val;
					}
					break;
					
				case Type::LONG_ARRAY:
					retrieved_val = getNumber(valid, Type::LONG);
					if(valid)
					{
						((long*)var.ptr)[index] = (long)retrieved_val;
					}
					break;
					
				case Type::CHAR_ARRAY:
						((char*)var.ptr)[index]  = getChar();
						break;
					
				case Type::BOOL_ARRAY: 
					bool temp_bool = getBool(valid);
					if(valid)
					{
						((bool*)var.ptr)[index] = temp_bool;
					}
					break;
			}
		}
		else
		{
			Serial.println(F("Invalid Selection"));
		}
		clearScreen();
		displayArray(var);
		Serial.println(F("Enter array index to be updated."));
	  index = getSelection();
	}
	
}

/**********************************************************
* @brief Retrieve a menu selection via the Serial Monitor
*
*  This method will prompt the user for a menu selection and allow the user to either
*  enter a numeric selection or quit the menu with Q or q.
*
*  @note This menu allows for a maximum value of 253. 255 is a conversion of the ASCII letter Q and
*        254 is used to denote an invalid number has been entered. An invalid entry is a non-numeric
*        value ("Hello!") or a number less than 0 (negative) or greater than 253.
*
*  @return byte The user's menu selection
***********************************************************/
byte Debugger::getSelection()
{
	byte selection = 0;
	Serial.print(F("Selection (Q to quit): "));
	while(Serial.available() == 0){}
	selection = Serial.peek();
	if(selection == 'Q' || selection == 'q')
	{
		Serial.println((char)selection);//Echo value entered
		selection = 255;//Exit menu
	}
	else
	{
		bool valid = true;
		selection = getNumber(valid, BYTE);
		if(!valid || selection > 253)
		{
			selection = 254;//Error occurred
			Serial.println(F("Invalid Selection"));
		}
	}
	clearBuffer();
	return selection;
}

/**********************************************************
* @brief Retrieve a number from the user and ensure it is both valid
*        and fits within a set number of bytes.
*
*  This method will read an ASCII number from the Serial port using Arduino'saves
*  Serial Library.  This method checks for valid values on 8-Bit & 32-Bit microcontrollers:
*		- 8-Bit: 
*			- Int (2 Bytes)
*			- Long (4 Bytes)
*		- 32-Bit: 
*			- Int (4 Bytes)
*			- Long (8 Bytes)
*
*
*  @note If the converted number causes overflow or does not fit within
*  the set number of bytes (parameter), this method will set the parameter
*  valid to false.
*  
*	 @param valid - a boolean (passed by reference) to check if the value retrieved was valid(true) or invalid(false)
*	 @param type - The type of number being used
*  @return long - The number entered by the user
***********************************************************/
long Debugger::getNumber(bool &valid, Type type)
{
	valid = true;//Assume value is valid
	bool outRange = false;//Determine if the number is too large/small
	char* eptr;//Points to the first character that COULD NOT be converted, may be null if all values could be converted
  char input[] = {0,0,0,0,0,0,0,0,0,0,0,0};
  while(Serial.available() == 0) {}//Wait for value
	
	//This code used to use Serial.readBytes() but the method call kept skipping the first digit entered
	//Uncertain as to why, so I am manually grabbing each individual byte/character
	byte counter = 0; 
	while(Serial.available() > 0 && counter < 12)
	{
		input[counter] = Serial.read();
		Serial.print(input[counter]);
		counter++;
	}
	clearBuffer();

  long result = strtol(input, &eptr, 10);//Convert user input to long
  if(!(*eptr == 0 || *eptr == 13 || *eptr == 10))
  {//Check if a non-numeric character was entered
    Serial.println(F("Not a number"));
		valid = false;
  }
  else if(errno == ERANGE)
  {//Check if the value was too large for a long
    outRange = true;
	}
	else if(type != LONG){
		long check = 0;
		switch(type)
		{//Verify the user input fits in the destination number size
			case Type::BYTE:
				check = (byte)result; 
				break;
				
			case Type::INT:
				check = (int)result;
				break;
				
		}
		if(check != result)
		{
			outRange = true;
		}
	}
	if(outRange)
	{
		Serial.println(F("Value Out of Range"));
		valid = false;
	}
	return result;
}

/**********************************************************
* @brief Retrieve a single character from the user 
*
*  This method will read an ASCII number from the Serial port 
*
*
*  @note No validation is performed. All characters are considered valid for this method. This could mean returning an ASCII Carriage Return or New Line.
*  
*	 @return char - The character entered by the user
***********************************************************/
char Debugger::getChar()
{
	Serial.print(F("(char): "));
	while(Serial.available() == 0){}
	char temp_char = Serial.read();
	Serial.println(temp_char);
	clearBuffer();
	clearScreen();
	return temp_char;
}

/**********************************************************
* @brief Retrieve a boolean from the user 
*
*  This method will read an ASCII string from the Serial port and convert it, if possible, to a boolean value. This method will set valid to false if the entry can not be converted to True or False.
*
*
*  @warning The validation is very simple. Only the first character is checked and all others are truncated from the Serial buffer. This means the method only checks for F/f or T/t. So if you enter "Today" this will be converted to the boolean value true. This was done to simplify the logic but does allow for invalid inputs from the user.
*  
*  @param valid - a boolean (passed by reference) to check if the value retrieved was valid(true) or invalid(false)
*
*	 @return bool - The boolean representation of the user's entry.
***********************************************************/
bool Debugger::getBool(bool &valid)
{
	bool value = true;
	valid = true;
	Serial.print("(bool): ");
	while(Serial.available() == 0){}
	byte bool_char = Serial.peek();
	while(Serial.available() != 0)
	{
		Serial.print((char)Serial.read());//Echo value back to Serial Monitor
	}
	
	if(bool_char == 'F' || bool_char == 'f')
	{
		value = false;
	}
	else if(bool_char != 'T' && bool_char != 't')
	{
		valid = false;
		Serial.println(F("Value must be (t)rue or (f)alse"));
	}
	clearBuffer();
	return value;
}


/**********************************************************
* @brief Set a chosen counter's maximum value
*
*  This method will set the number of times a specific counter can be called before
*  pausing the Serial Monitor.
*
*
*  @note No validation is performed on value. All byte values are considered valid, from 0 to 255. 
*  @note id is validated and must be a possible index for the counters_max array
*	 
*	 @param id - The index of the counter being set
*	 @param value - The max value for the chosen counter
***********************************************************/
void Debugger::setCounter(byte id, byte value)
{
	if(id > sizeof(counters_max) / sizeof(counters_max[0]))
	{
		Serial.print(id);
		Serial.print(F(" is too large. The id must be less than"));
		Serial.print(sizeof(counters_max) / sizeof(counters_max[0]));
	}
	else
	{
		counters_max[id] = value;
		counters[id] = value;
	}
}

/**********************************************************
* @brief Display the value of hardware pins and watched variables & update the default counter[0]. This method is hard coded to 3 iterations.
*
*  This method will display the current state of the board's hardware pins and current 
*  value for variables added to the watch list. If a subset of pins has been chosen, then only
*  the current state for subset will shown. This method then decrements the default counter [0]. If the default counter reaches 0, then the Serial Monitor will be paused and the counter will be reset.
*
*
***********************************************************/
void Debugger::repeat()
{
	repeat(3, 0, ALL_DATA);	
}

/**********************************************************
* @brief Display the value of hardware pins and watched variables and update the default counter
*
*  This method will display the current state of the board's hardware pins and current 
*  value for variables added to the watch list. If a subset of pins has been chosen, then only
*  the current state for subset will shown. This method then decrements the default counter [0]. If the default counter reaches 0, then the Serial Monitor will be paused and the counter will be reset.
*
*  @param value - Value for the default (0) counter
***********************************************************/
void Debugger::repeat(byte value)
{
	repeat( value,0, ALL_DATA);
}

/**********************************************************
* @brief Display the value of hardware pins and watched variables and update the chosen counter
*
*  This method will display the current state of the board's hardware pins and current 
*  value for variables added to the watch list. If a subset of pins has been chosen, then only
*  the current state for subset will shown. This method then decrements the chosen counter. If the chosen counter reaches 0, then the Serial Monitor will be paused and the counter will be reset.
*
*  @param value - Value for the chosen counter
*	 @param id 	  - index of the chosen counter
***********************************************************/
void Debugger::repeat(byte value, byte id)
{
	repeat(value, id, ALL_DATA);
}

/**********************************************************
* @brief Display the chosen data information and update the chosen counter
*
*  This method will display the chosen information based on the constants VARIABLES (0), PINS (1), 
*  and ALL_DATA (2). This allows the programmer to view only the variables in the watchlist, the state of the hardware pins (subset of pins displayed if set), or both sets of information.  The chosen counter is also decremented and if it reaches 0 then the Serial Monitor will be paused and the counte reset.
*
*  @warning The id is validated and must be a valid index for the counters_max array. 
*  @warning The data parameter must be valid entry (0-2), otherwise no information will be displayed, only a warning message 
* 
*  @param value - Value for the chosen counter
*  @param id - the index of the chosen counter
*  @param data - the type of information to display.
***********************************************************/
void Debugger::repeat(byte value, byte id, byte data)
{
	if(debuggingIsOn)
	{
		if(id > sizeof(counters_max) / sizeof(counters_max[0]))
		{
			Serial.println(F("Invalid counter ID"));
		}
		else
		{
			if(counters_max[id] != value)
			{
				setCounter(id, value);
			}
			counters[id]--;
			Serial.print(F(" REPEAT ID: "));
			Serial.print(id);
			Serial.print(F(" | Counter: "));
			Serial.print(counters_max[id] - counters[id]);
			Serial.print(F(" of "));
			Serial.println(counters_max[id]);
			print(data);
			if(counters[id] == 0)
			{
					counters[id] = counters_max[id];//Reset counters
					pause();
			}
		}
	}
}

/**********************************************************
* @brief Display the value of hardware pins and watched variables, only once
*
*  This method will display the current state of the board's hardware pins and current 
*  value for variables added to the watch list. If a subset of pins has been chosen, then only
*  the current state for subset will shown. This method does not pause the running program.
*
*  @note This method does not pause the running Arduino Program
*
***********************************************************/
void Debugger::print()
{
	print("", ALL_DATA);	
}

/**********************************************************
* @brief Display the value of hardware pins and watched variables, only once
*
*  This method will display the current state of the board's hardware pins and current 
*  value for variables added to the watch list. If a subset of pins has been chosen, then only
*  the current state for subset will shown. This method does not pause the running program.
*
*  @note This method does not pause the running Arduino Program
*
*  @param name - An identifier for where the print statement has been placed in the running program
***********************************************************/
void Debugger::print(char name[])
{
	print(name, ALL_DATA);	
}

/**********************************************************
* @brief Display the chosen data information
*
*  This method will display the chosen information based on the constants VARIABLES (0), PINS (1), 
*  and ALL_DATA (2). This allows the programmer to view only the variables in the watchlist, the state of the hardware pins (subset of pins displayed if set), or both sets of information.  
*
*  @warning The data parameter must be valid entry (0-2), otherwise no information will be displayed, only a warning message 
* 
*  @param name - An identifier for where the print statement has been placed in the running program
*  @param data - the type of information to display.
***********************************************************/
void Debugger::print(char name[], byte data)
{
	if(debuggingIsOn)
	{
		drawStars();
		Serial.print(F("\tPrint - "));
	  Serial.println(name);
		drawStars();
		if(data == VARIABLES)
		{
			displayVariables();
		}
		else if(data == PINS)
		{
			if(usePinList)
			{
				displaySubsetPins();
			}
			else
			{
				displayPins();
			}
		}
		else if(data == ALL_DATA)
		{
			if(usePinList)
			{
				displaySubsetPins();
			}
			else
			{
				displayPins();
			}
			displayVariables();
		}
		else
		{
			Serial.print(F("Error: Invalid data value"));
		}
	}
}

/**************************************************************************
* 
*  @brief Pause the currently running Arduino program
*	
*	This method will pause the arduino program and wait until the user
*			enters a value via the Serial port to continue
*	@note This method requires the Serial port to have a connection in order to
*			work correctly.
***/    
void Debugger::pause()
{
	if(Serial)
	{//Verify the Serial port is accessible
		Serial.println(F("Press ENTER to continue"));
		while(Serial.available() == 0){} //Wait until input is provided on the Serial port
		clearBuffer();
	}
}


/**************************************************************************
* 
*  @brief Clear the Serial Buffer
*	
*	 This method will remove any characters within the Serial Buffer
***/
void Debugger::clearBuffer()
{ int flush = timedPeek();
	while(flush != -1)
	{//remove any remaining values from the Serial buffer
		Serial.read();
		flush = timedPeek();
	}
}

/**************************************************************************
* 
*  @brief Clear the screen on Serial Monitor
*	
*	 This method will "clear" the screen by feeding a series of newlines to move the
*  location in the Serial Monitor to be further down.  
***/
void Debugger::clearScreen()
{
	for(int i = 0; i < 15; i++)
	{
		Serial.println();
	}
}

/***********************************************************
* 
*  Print a series of asterisks on the Serial monitor.
*	
***/
void Debugger::drawStars()
{
	Serial.print(F("\t"));
	for(int i = 0; i < 50; i++)
	{
		Serial.print('*');
	}
	Serial.println();
}

/**********************************************************
* @brief Perform a Serial peek with a set timeout period (1 second)
*
* @note This code was taken from the Arduino Library's Serial communication method. The original method is protected, so it was transferred here for our use.
***********************************************************/
int Debugger::timedPeek()
{
  int c;
  unsigned long startMillis = millis();
  do {
    c = Serial.peek();
    if (c >= 0) return c;
  } while(millis() - startMillis < 1000);//default timeout
  return -1;     // -1 indicates timeout
}